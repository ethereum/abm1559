# abm1559

Agent-based simulation environment for EIP 1559.
